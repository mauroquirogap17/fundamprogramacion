#Haz una tabla de multiplicar utilizando el ciclo for 
num = 4

for i in range(1,11):
  print(i,"x",num,"= ",i * num)