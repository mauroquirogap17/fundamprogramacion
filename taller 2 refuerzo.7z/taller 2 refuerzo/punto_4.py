#Crear un bucle que cuente todos los números pares hastael 100 ciclo for

cant = 0

for i in range(0,100,2):
  
  cant = cant + 1
print(f"La cantidad de numeros pares hasta el 100 es= {cant}")