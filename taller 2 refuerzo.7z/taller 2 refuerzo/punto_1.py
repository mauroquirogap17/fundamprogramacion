# 1. Se necesita un sistema que despliega una tabla de multiplicar de un número dado por el usuario. ciclo for
num = int(input("Digite un numero: "))

for i in range(1,11):
  print(i,"x",num,"= ",i * num)