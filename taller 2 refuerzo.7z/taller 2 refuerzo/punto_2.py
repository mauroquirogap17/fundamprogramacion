#2. Se necesita un sistema que pida un sueldo de un trabajador, si el sueldo es mayor a 655000, no tedrá 
# ninguna bonificación, pero si es menor tiene bonificacióndel 4%. Al final se desea saber el total del sueldo
#  cono sin bonificación. Preguntar si desea ejecutar de nuevo el programa con el ciclo while.

resp = "si"
while resp == "si" or resp == "SI" or resp == "Si" or resp == "s":

        sueldo = float(input("Digite su sueldo :"))
        if sueldo > 655000:
         print(f"\nNo aplica para bonificacion por sueldo\nEl total del pago es = ${sueldo:,.0f}")
        
        else:
         boni =sueldo * 0.04
         sueldo_bono = sueldo + boni
         print(f"\nPor sueldo aplica para bonificacion de 4% = ${boni:,.0f},.\nEl total del pago es = ${sueldo_bono:,.0f}")
        resp = input("\nDesea validar otro sueldo?")            
  
