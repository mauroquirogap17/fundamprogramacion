//alert('prueba')

var nombre = "Mauricio Quiroga ";
var edad = 30;
var gusta_mundial= "si";

var datos = document.getElementById("datos");

datos.innerHTML=`

<h2> Mi nombre es: ${nombre} </h2>
<h2> Mi edad es:${edad}</h2>

`;
if(gusta_mundial == "si"){
    datos.innerHTML+= '<h2> Eres futbolero </h2>';
}
else{
    datos.innerHTML+='<h2> No eres futbolero</h2>'
}