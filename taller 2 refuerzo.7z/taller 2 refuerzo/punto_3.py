#3. Un maestro necesita un sistema para capturar las calificaciones de 5 parciales de sus alumnos, después
# recapturarlas necesita que se despliegue el promedio, cuando ya no quiera capturar más alumnos, necesita que
# se despliegue el promedio general de todos los alumnos capturados. Preguntar si desea ejecutar de nuevo el
#programa con el ciclo while.
cant=0
prom_acu=0
resp = "si"
while resp == "si" or resp == "SI" or resp == "Si" or resp == "s":
    cal1 = float(input("Digite la calificación 1: "))
    cal2 = float(input("Digite la calificación 2: "))
    cal3 = float(input("Digite la calificación 3: "))
    cal4 = float(input("Digite la calificación 4: "))
    cal5 = float(input("Digite la calificación 5: "))
    prom= (cal1+cal2+cal3+cal4+cal5)/5
     
    print(f"El promedio del estudiante es= {prom}")
    resp = input("Ingresar notas de otro estudiante?")

    cant=cant + 1
    prom_acu=prom_acu + prom
    prom_gen= prom_acu/ cant

print(f"El promedio general de los {cant} estudiantes ingresados es = {prom_gen}")